import os
for filename in os.listdir("."):
    if filename.startswith("mb"):
        os.rename(filename, "mercedez-benz" + filename[2:])
